from faker import Factory
import json
from math import floor

# functions to generate random values
from random import expovariate, normalvariate, choice, randint, random, shuffle

# Constants for Stores model
MIN_RATING = 1
MAX_RATING = 5
CITIES = ('Alameda', 'Belmont', 'Berkeley',
          'Castro Valley', 'Concord',
          'Danville', 'Dublin', 'El Cerrito', 'Emeryville',
          'Fremont', 'Half Moon Bay', 'Hayward', 'Livermore',
          'Martinez', 'Oakland', 'Pleasanton', 'Richmond',
          'San Francisco', 'San Leandro', 'San Mateo',
          'San Ramon', 'Union City')
CUISINES = ('Afghan',
            'American',
            'Chinese',
            'Indian',
            'Italian',
            'Japanese',
            'Mediterranean',
            'Mexican'
            )
FOODS = ('Bagels',
         'Breakfast & Brunch',
         'Buffet',
         'Coffee & Tea',
         'Donuts',
         'Ice Cream',
         'Pizza',
         'Snacks'
         )
ALL_CATEGORIES = CUISINES + FOODS

# Constants to manage values in documents to generate
MIN_CATEGORIES = 1
MAX_CATEGORIES = 3
MIN_REVIEWS = 0
MAX_REVIEWS = 1000
MAX_PARAGRAPHS = 5 # max number of paragraphs in comments

COMMENTS = [('Filthy', 'Will make you sick', 'Yuck!', 'Cheated me!'),
            ('Poor', 'At least I did not get sick', 'Little flavor', 'Felt cheated'),
            ('Fair', 'Clean, at least', 'Ok', 'You get what you pay for'),
            ('Good', 'Would come back', 'Solid meal', 'Fairly authentic'),
            ('Great food', 'My new go-to place', 'The desserts are to die for', 'Da bomb!')
            ]

NO_REVIEWS_PROB = 0.05
REVIEWS_LAMBDA = 3  # for exponential distribution

# Faker random value generator
generator = Factory.create()

# dict to save used store names
used_storenames = {}

# Output files
store_file = None

class store(object):
    def __init__(self, name, address, city, cost, categories, delivery, takeout, reviews):
        self.name = name
        self.address = address
        self.city = city
        self.cost = cost
        self.categories = categories
        self.delivery = delivery
        self.takeout = takeout
        self.reviews = reviews

    def __str__(self):
        '''
        Return JSON string for entire store document,
        compatible with mongoimport
        '''
        storedict = {}
        storedict["name"] = self.name
        storedict["address"] = self.address
        storedict["city"] = self.city
        storedict["cost"] = self.cost
        storedict["categories"] = self.categories
        storedict["delivery"] = self.delivery
        storedict["takeout"] = self.takeout
        storedict["reviews"] = self.reviews
        return json.dumps(storedict)

def gen_from_prob_table(probabilities):
    '''
    Return a random integer from 1 to len(probabilities),
    following the cumulative probabilities of the parameter
    '''
    rand_val = random()
    prob_index = 0
    while prob_index < len(probabilities):
        if rand_val < probabilities[prob_index]:
            break
        prob_index += 1
    return prob_index + 1

def gen_rating():
    '''Return random rating, trying to factor in
    the tendency of reviews to give higher ratings
    https://www.yelp.com/factsheet has current distributions.
    '''
    probabilities = [.15, .22, .32, .54, 1.0]
    return gen_from_prob_table(probabilities)

def gen_by_first_name():
    '''
    Generate name for a restaurant based on a first name
    '''
    prefixes = ('House of ', 'Chez ', 'Barbecue ', 'Chef ')
    suffixes = ("'s", "'s Place", "'s Cafe", "'s Golden Chicken")
    name = generator.first_name()
    if randint(0,1): # 1 == True for adding a prefix
        return choice(prefixes) + name
    else: return name + choice(suffixes)

def gen_by_country():
    '''
    Generate name for a restaurant based on a country name
    '''
    suffixes = (" House", " Garden", " Kitchen", " Cafe", " Bistro", " Grill")
    name = generator.country()
    return name + choice(suffixes)

def gen_restaurant_name():
    '''
    Generate a random restaurant name
    '''
    gen_fns = (gen_by_first_name, gen_by_country)
    return choice(gen_fns)()

def gen_cost():
    '''
    Generate cost rating, an integer rating
    '''
    # Probabilities of $, $$, $$$, $$$$ for yelp-like cost measure
    probabilities = [.45, .8, .95, 1.0]
    return gen_from_prob_table(probabilities)

def gen_categories():
    '''
    Generate a random list of categories
    '''
    if randint(0,1): # 1 == True for generating just one
        return [choice(ALL_CATEGORIES)]
    else: return [choice(CUISINES), choice(FOODS)]

def gen_single_review():
    '''
    Generate a single review
    '''
    rating = gen_rating()
    # While the "lorem" generator can produce appropriate sizes
    # of text, the amount of text gets a bit overwhelming,
    # and it's in Latin
    comments = choice(COMMENTS[rating-1])
    return {"rating":rating, "comments":comments}

def gen_reviews():
    '''
    Generate list of reviews
    '''
    if random() < NO_REVIEWS_PROB:
        return []   # no reviews
    num_reviews = int(expovariate(REVIEWS_LAMBDA)*MAX_REVIEWS)
    if num_reviews > MAX_REVIEWS:
        num_reviews = MAX_REVIEWS
    reviews = []
    for rev_index in range(num_reviews):
        reviews.append(gen_single_review())
    return reviews

def gen_delivery():
    '''
    Does the restaurant deliver food?
    '''
    DELIVERY_PROB = 0.05 # most places do not deliver
    return random() < DELIVERY_PROB
    
def gen_takeout():
    '''
    Does the restaurant offer takeout?
    '''
    TAKEOUT_PROB = 0.6 # a lot of places do
    return random() < TAKEOUT_PROB
    
def generate_single_store():
    ''' Generate fields for one store
    '''    
    new_store = store(gen_restaurant_name(),
                       generator.street_address(),
                       choice(CITIES),
                       gen_cost(),
                       gen_categories(),
                       gen_delivery(),
                       gen_takeout(),
                       gen_reviews())
    store_file.write(str(new_store) + '\n')
    return new_store
   
def generate_stores(num_stores):
    '''
    Generate store records
    '''
    for store_index in range(num_stores):
        generate_single_store()
    store_file.close()
        
if __name__ == '__main__':
    import sys
    store_file = open('/tmp/stores.json', 'w')

    if len(sys.argv) == 1:
        to_generate = 20000
    else:
        to_generate = int(sys.argv[1])
    generate_stores(to_generate)
            
